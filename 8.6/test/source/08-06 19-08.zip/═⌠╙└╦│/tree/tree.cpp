#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <vector>
#include <queue>
#include <stack>
#define maxn 100011

using namespace std;

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	printf("184524");
	return 0;
}
