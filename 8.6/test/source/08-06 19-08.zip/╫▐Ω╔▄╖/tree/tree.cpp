#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int x,y,z,n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	cin>>x>>y>>z;
	cout<<"184524";
	return 0;
}
