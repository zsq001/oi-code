#include<cstdio>
#include<algorithm>
using namespace std;

int n,m;
int a[200050];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	printf("Error!");
	return 0;
}
