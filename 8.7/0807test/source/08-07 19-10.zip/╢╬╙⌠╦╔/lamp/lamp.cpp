#include<stdio.h>
#include<algorithm>
using namespace std;
int main()
{
	freopen("lamp.in","r",stdin);
	freopen("lamp.out","w",stdout);
	int a=1;
	printf("%d",a);
	return 0;
}
