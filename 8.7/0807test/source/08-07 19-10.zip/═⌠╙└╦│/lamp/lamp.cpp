#include <cstdio>
int main() {
	freopen("lamp.in", "r", stdin);
	freopen("lamp.out", "w", stdout);
	printf("1");
	return 0;
}
