#include<cstdio>
int main()
{
	freopen("toad.in","r",stdin);
	freopen("toad.out","w",stdout);
	printf("Impossible\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
