#include<stdio.h>
#include<stdlib.h>
int T,a,b,x,y;
int main()
{
	freopen("vector.in","r",stdin);
	freopen("vector.out","w",stdout);
	int i;
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
		scanf("%d%d%d%d",&a,&b,&x,&y);
	}
	printf("Y\nN\nY");
	return 0;
}
