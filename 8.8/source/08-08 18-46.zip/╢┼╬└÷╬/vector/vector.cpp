#include <stdio.h>
int main()
{
	freopen("vector.in","r",stdin);
	freopen("vector.out","w",stdout);
	printf("Y\nN\nY\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
