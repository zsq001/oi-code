#include<iostream>
#include<cstdio>
using namespace std;

int main()
{
	freopen("vector.in","r",stdin);
	freopen("vector.out","w",stdout);
	int t;
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		int a,b,x,y;
		cin>>a>>b>>x>>y;	
	}
	cout<<"Y"<<endl<<"N"<<endl<<"Y";
	return 0;
}

